package com.app.dto;

import lombok.Data;

@Data
public class CheckMailForOTPDto {
	public String email;
}
