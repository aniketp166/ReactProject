package com.app.service;

import com.app.dto.TestDriveDto;
import com.app.pojos.BookService;
import com.app.pojos.bookTestDrive;

public interface ITestDrive {

	String bookTestdrive(TestDriveDto bs);

}
