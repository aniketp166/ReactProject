package com.cdac.Service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.cdac.CustomException.ResourceNotFoundException;
import com.cdac.dao.VehicleModelRepository;
import com.cdac.dto.VehicleModelDto;
import com.cdac.entity.VehicleModel;
import com.cdac.entity.VehicleSpecification;

@Service
@Transactional
public class VehicleModelServiceImpl implements IVehicleModelService {
	
	
	
	@Autowired
	private VehicleModelRepository vehModelRepo;
	
	@Value("${file.upload.location}")
	private String location;
	
	
	
	@Override
	public VehicleModel addVehicleModelDetails(VehicleModelDto transientVehModel, MultipartFile imageFile) 
			throws IllegalStateException, IOException {
		// TODO Auto-generated method stub
		System.out.println(location);
		VehicleModel vehmodel =new VehicleModel();
		VehicleSpecification vehmodspec = new VehicleSpecification();
		vehmodspec.setEngineCC(transientVehModel.getEngineCC());
		vehmodspec.setEngineCylinderinfo(transientVehModel.getEngineCylinderinfo());
		vehmodspec.setSegment(transientVehModel.getSegment());
		vehmodspec.setTransmission(transientVehModel.getTransmission());
		vehmodspec.setSeatingCapacity(transientVehModel.getSeatingCapacity());
		vehmodspec.setMileage(transientVehModel.getMileage());
		vehmodspec.setFuelTankCapacity(transientVehModel.getFuelTankCapacity());
	
		
		vehmodel.setModelName(transientVehModel.getModelName());
		vehmodel.setQuantity(transientVehModel.getQuantity());
		vehmodel.setVehicleSpecification(vehmodspec);
		vehmodel.setBasePrice(transientVehModel.getBasePrice());
		imageFile.transferTo(new File(location,imageFile.getOriginalFilename()));
		vehmodel.setImageName(imageFile.getOriginalFilename());
		return vehModelRepo.save(vehmodel);
	}



	@Override
	public List<VehicleModel> getListOfAvailableModel() {
		// TODO Auto-generated method stub
		return vehModelRepo.findAll();
	}



	@Override
	public VehicleModel updateVehicleModel(VehicleModel vehicleModel) {
		// TODO Auto-generated method stub
		return vehModelRepo.save(vehicleModel);
	}



	@Override
	public VehicleModel getVehicleModelDetails(Integer ModelId) {
		// TODO Auto-generated method stub
		return vehModelRepo.findById(ModelId).orElseThrow(() -> new ResourceNotFoundException("model with id"+ModelId+" not found...!!!!!"));
		
	}



	@Override
	public String deleteVehicleModel(Integer id) {
		// TODO Auto-generated method stub
		 vehModelRepo.deleteById(id);
		 return "Model successfully deleted...!!!";
	}
}

