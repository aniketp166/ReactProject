package com.cdac.Service;

import java.util.List;

import com.cdac.entity.Employee;

public interface IEmployeeService {

	List<Employee> listOfEmployee();

	Employee getEmployeeDetailsById(int empId);

	Employee addEmployeeDetails(Employee emp);

	Employee updateEmployeeDetails(Employee emp);

	String DeleteEmployeeDetails(int empId);

}
