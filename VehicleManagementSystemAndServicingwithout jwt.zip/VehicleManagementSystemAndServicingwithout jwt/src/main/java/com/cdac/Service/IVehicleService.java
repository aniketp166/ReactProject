package com.cdac.Service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.cdac.entity.Vehicle;

public interface IVehicleService {

	List<Vehicle> listOfVehicles();
	
	String addVehiclesList(MultipartFile vehicleList) throws IOException;
	
	Vehicle updateVehicleDetails(Vehicle veh);

	String deleteVehicleDetails(String chassisNo);

	List<Vehicle> soldVehicles();

	Vehicle getVehicleDetailsByChassisNo(String chassisNo);

	List<Vehicle> listOfBookedVehicles();

	Vehicle purchaseVehicle(String vehId);

	int addVehicleNumber(String vehicleNumber, String chNo);

	String checkAvailabilityForBooking(String modelName, String color);

	Vehicle bookVehicle(String modelName, String color, Integer custId);

	

	
}
