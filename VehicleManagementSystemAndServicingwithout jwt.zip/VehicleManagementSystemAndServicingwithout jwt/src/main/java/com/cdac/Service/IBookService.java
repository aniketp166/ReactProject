package com.cdac.Service;

import java.util.List;

import com.cdac.dto.ServiceDto;
import com.cdac.entity.BookService;

public interface IBookService {

	List<BookService> listOfBookingServices();

	BookService getServiceDetails(int id);

	BookService bookService(ServiceDto bs);

	String removeServiceDetails(int id);

	
	
//	*********************
//	EmployeeController Service Implementations
	
	List<BookService> getBookedServices();

	BookService updateService(ServiceDto bookSer);



}
