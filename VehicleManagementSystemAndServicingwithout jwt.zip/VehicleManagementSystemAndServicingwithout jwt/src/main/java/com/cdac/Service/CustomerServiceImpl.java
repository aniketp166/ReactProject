package com.cdac.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cdac.CustomException.ResourceNotFoundException;
import com.cdac.dao.CustomerAdmRepository;
import com.cdac.entity.Customer;

@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	private CustomerAdmRepository custRepo;
	
	@Autowired
	private JavaMailSender mailSender;
	
	@Override
	public List<Customer> listOfCustomers() {
		// TODO Auto-generated method stub
		return custRepo.findAll();
	}



	@Override
	public Customer getCustomerDetailsById(int custId) {
		// TODO Auto-generated method stub
		return custRepo.findById(custId)
				.orElseThrow(() -> new ResourceNotFoundException("Customer with id " + custId + " not found!!!!!!!!!"));
	}



	@Override
	public Customer addCustomerDetails(Customer transientCust) {
		// TODO Auto-generated method stub
		if(custRepo.existsById(transientCust.getId())) {
		return null;
	}
		return custRepo.save(transientCust);

	}



	@Override
	public Customer updateCustomerDetails(Customer customer) {
		// TODO Auto-generated method stub
		
		return custRepo.save(customer);
	}



	@Override
	public String DeleteCustomerDetails(int custId) {
		// TODO Auto-generated method stub
		if (custRepo.existsById(custId)) {
			custRepo.deleteById(custId);
			return "Customer Details deleted with" + custId;
		}
		return null;
	}



	@Override
	public Customer getCustomerDetailsByEmail(String email) {
		// TODO Auto-generated method stub
		return custRepo.findByEmailId(email);
	}

	


	

}
