package com.cdac.Service;

import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.cdac.dao.CustomerAdmRepository;
import com.cdac.dao.RoleRepository;
import com.cdac.dao.UserRepository;
import com.cdac.dao.forgotPasswordRepository;
import com.cdac.dto.ChangePasswordDto;
import com.cdac.dto.SignUpRequest;
import com.cdac.dto.UserResponseDTO;
import com.cdac.entity.Customer;
import com.cdac.entity.ForgotPassword;
import com.cdac.entity.Role;
import com.cdac.entity.User;
import com.cdac.entity.UserRoles;

@Service
@Transactional
public class UserServiceImpl implements IUserService {
		
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private RoleRepository roleRepo;
//	@Autowired
//	private PasswordEncoder encoder;
	@Autowired
	private CustomerAdmRepository custRepo;
	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
	private forgotPasswordRepository forgotRepo;
	
	@Override
	public UserResponseDTO registerUser(SignUpRequest request) {
		// TODO Auto-generated method stub
		
		User user = new User();
		user.setUserName(request.getUserName());
		user.setEmail(request.getEmail());
		user.setPassword((request.getPassword()));
		System.out.println(request.getRoles());
		
		Set<Role> roles = request.getRoles().stream()
				// mapping roleName --> Role (using RoleRepo)
				.map(roleName -> roleRepo.findByUserRole(UserRoles.valueOf(roleName)).get())
				// collect in a Set<Role>
				.collect(Collectors.toSet());
		
		
		user.setRoles(roles);
		user.setActive(true);
		
		User persistentUser = userRepo.save(user);
		UserResponseDTO dto = new UserResponseDTO();
		Customer customer = new Customer();
		customer.setName(request.getUserName());
		customer.setEmailId(request.getEmail());
		customer.setAddress(request.getAddress());
		customer.setActive(true);
		customer.setContactNumber(request.getContactNumber());
		customer.setDateOfRegistration(request.getDateOfRegistration());
		
		
		Customer persistenceCustomer = custRepo.save(customer);
		BeanUtils.copyProperties(persistentUser, dto);
		return dto;
	}

	@Override
	public User getUserDetails(String email) {
		// TODO Auto-generated method stub
		return userRepo.findByEmail(email).orElseThrow();
	}

	@Override
	public User getuserDetailsForOTP(String emailId) {
		// TODO Auto-generated method stub
		try {
			System.out.println("start");
			User user = userRepo.findByEmail(emailId).orElseThrow();
			System.out.println("after");
			if(user != null) {
				ForgotPassword forgotPassPresent = forgotRepo.findByEmail(emailId);
				
				if(forgotPassPresent != null) {
					forgotRepo.deleteById(forgotPassPresent.getId());
				}
			
				SimpleMailMessage msg = new SimpleMailMessage();
				msg.setFrom("pranaliphadatare07@gmail.com");
				msg.setFrom(emailId);
				Random random = new Random();
				int num = random.nextInt(100000);
				msg.setText("OTP :"+num);
				msg.setSubject("OTP from Vehicle Showroom & Service Management");
				ForgotPassword newOtp = new ForgotPassword();
				newOtp.setEmail(emailId);
				newOtp.setOtp(num);
				forgotRepo.save(newOtp);
				mailSender.send(msg);
				
				return user;
			}
		return null;
	}catch(RuntimeException e){
		System.out.println("in catch of OTP");
		return null;
		}
	}

	@Override
	public String changePassword(ChangePasswordDto changePass) {
		// TODO Auto-generated method stub
		try {
			ForgotPassword forgotPassPresent = forgotRepo.findByEmail(changePass.getEmail());
			double dbOtp = forgotPassPresent.getOtp();
			double customerOtp = changePass.getOtp();
			System.out.println(dbOtp);
			System.out.println(customerOtp);
			if(dbOtp == customerOtp) {
				User user = userRepo.findByEmail(changePass.getEmail()).orElseThrow();
				user.setPassword((changePass.getPassword()));
				userRepo.save(user);
				if(forgotPassPresent != null) {
					forgotRepo.deleteById(forgotPassPresent.getId());
					
				}return "Password changed";
				
			}		return null;
		
		}catch(NoSuchElementException e) {
			return null;
		}
		

	}

}
