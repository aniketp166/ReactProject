package com.cdac.Service;

import java.util.List;

import com.cdac.entity.Admin;



public interface IAdminService {
	
	Admin loginAdmin(String email, String password);

	List<Admin> listAdmin();
}
