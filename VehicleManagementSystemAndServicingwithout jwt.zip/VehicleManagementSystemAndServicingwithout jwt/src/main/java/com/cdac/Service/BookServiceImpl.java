package com.cdac.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cdac.CustomException.ResourceNotFoundException;
import com.cdac.dao.ServiceRepository;
import com.cdac.dao.ServiceTypeRepository;
import com.cdac.dto.ServiceDto;
import com.cdac.entity.BookService;

@Service
@Transactional
public class BookServiceImpl implements IBookService {
	
	@Autowired
	private ServiceRepository serviceRepo;
	
	@Autowired
	private ServiceTypeRepository serviceTypeRepo;
	
	
	@Override
	public List<BookService> listOfBookingServices() {
		// TODO Auto-generated method stub
		return serviceRepo.findAll();
	}


	@Override
	public BookService getServiceDetails(int id) {
		// TODO Auto-generated method stub
		return serviceRepo.findById(id).orElseThrow(
				()-> new ResourceNotFoundException("Service details with id " + id + " not found!!!!!!!!!"));
	}


	@Override
	public BookService bookService(ServiceDto bs) {
		// TODO Auto-generated method stub
		BookService bookedservice = new BookService();
		bookedservice.setCustomerName(bs.getCustomerName());
		bookedservice.setKmsDriven(bs.getKmsDriven());
		bookedservice.setCustomerId(bs.getCustomerId());
		bookedservice.setEmpId(0);
		bookedservice.setModelName(bs.getModelName());
		bookedservice.setServiceBookingDate(bs.getServiceBookingDate());
		bookedservice.setServicingDate(bs.getServicingDate());
		bookedservice.setVehicleNo(bs.getVehicleNo());
		
		BookService saved = serviceRepo.save(bookedservice);
		return saved;
	}


	@Override
	public String removeServiceDetails(int id) {
		// TODO Auto-generated method stub
		if (serviceRepo.existsById(id)) {
			serviceRepo.deleteById(id);
			return "Service Details deleted with" + id;
		}
		return null;
	}

	//From EmployeeController
	@Override
	public List<BookService> getBookedServices() {
		// TODO Auto-generated method stub
		return serviceRepo.findAll();
	}


	@Override
	public BookService updateService(ServiceDto bookSerDetails) {
		// TODO Auto-generated method stub
		BookService bookService = serviceRepo.findById(bookSerDetails.getId()).orElseThrow();
		System.out.println(bookService);
		return null;

}
	}
