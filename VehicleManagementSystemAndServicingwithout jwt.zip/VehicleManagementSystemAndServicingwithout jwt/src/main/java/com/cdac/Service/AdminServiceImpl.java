package com.cdac.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cdac.dao.AdminRepository;
import com.cdac.entity.Admin;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {

	@Autowired
	private AdminRepository AdminRepo;

	@Autowired
	private JavaMailSender mailSender;
	
	@Override
	public Admin loginAdmin(String email, String password) {
		
		Admin log = AdminRepo.findByEmailAndPassword(email, password);
		if(log != null) {
			sendEmail(email, "Login to the VS&SM Website", "did you logged into the website VS&SM");
			return log;
		}
		return log;

	}

	@Override
	public List<Admin> listAdmin() {
		
		return AdminRepo.findAll();
	}
	
	private void sendEmail(String toEmail, String Subject, String body) {
		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setFrom("pranaliphadatare07@gmail.com");
		msg.setTo(toEmail);
		msg.setText(body);
		msg.setSubject(Subject);
		
		mailSender.send(msg);
		
		System.out.println(msg + "This msg send successfully to " + toEmail);
	}
}
