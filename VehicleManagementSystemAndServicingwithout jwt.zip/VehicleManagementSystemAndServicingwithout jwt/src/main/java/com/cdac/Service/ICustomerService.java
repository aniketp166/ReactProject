package com.cdac.Service;

import java.util.List;

import com.cdac.entity.Customer;



public interface ICustomerService {

	List<Customer> listOfCustomers();

	

	Customer getCustomerDetailsById(int custId);



	Customer addCustomerDetails(Customer cust);



	Customer updateCustomerDetails(Customer cust);



	String DeleteCustomerDetails(int custId);



	Customer getCustomerDetailsByEmail(String email);

}
