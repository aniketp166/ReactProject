package com.cdac.Service;

import java.util.List;

import com.cdac.dto.InvoiceServiceDto;
import com.cdac.dto.InvoiceVehicleDto;
import com.cdac.entity.Invoice;



public interface IInvoiceService {

	List<Invoice> listofInvoices();

	InvoiceServiceDto bookServiceInvoice(int id);

	InvoiceVehicleDto purchaseVehcleInvoice(String chassisNo);

	InvoiceVehicleDto bookVehicleInvoice(int custId, String chassisNo);
}
