package com.cdac.Service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.cdac.dto.VehicleModelDto;
import com.cdac.entity.VehicleModel;

public interface IVehicleModelService {

	

	VehicleModel addVehicleModelDetails(VehicleModelDto veh, MultipartFile image)throws IllegalStateException,IOException;
	
	
	List<VehicleModel> getListOfAvailableModel();


	VehicleModel updateVehicleModel(VehicleModel vehicleModel);


	VehicleModel getVehicleModelDetails(Integer id);

	
	String deleteVehicleModel(Integer id);

}
