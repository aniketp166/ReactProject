package com.cdac.Service;

import com.cdac.dto.ChangePasswordDto;
import com.cdac.dto.SignUpRequest;
import com.cdac.dto.UserResponseDTO;
import com.cdac.entity.User;
//Nothing to do with spring security : it's job currently is user registration
public interface IUserService {

	UserResponseDTO registerUser(SignUpRequest request);

	User getUserDetails(String email);

	User getuserDetailsForOTP(String emailId);

	String changePassword(ChangePasswordDto changePass);

}
