package com.cdac.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cdac.CustomException.ResourceNotFoundException;
import com.cdac.dao.EmployeeRepository;
import com.cdac.dao.RoleRepository;
import com.cdac.dao.UserRepository;
import com.cdac.entity.Employee;
import com.cdac.entity.Role;
import com.cdac.entity.User;
import com.cdac.entity.UserRoles;

@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private EmployeeRepository empRepo;
	
	@Autowired
	private RoleRepository roleRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Override
	public List<Employee> listOfEmployee() {
		// TODO Auto-generated method stub
		return empRepo.findAll();
	}


	@Override
	public Employee getEmployeeDetailsById(int empId) {
		// TODO Auto-generated method stub
		return empRepo.findById(empId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee with id " + empId + " not found!!!!!!!!!"));
	}


	@Override
	public Employee addEmployeeDetails(Employee employee) {
		// TODO Auto-generated method stub
		User user = new User();
		user.setActive(true);
		user.setEmail(employee.getEmailId());
		user.setPassword(employee.getPassword());
		user.setUserName(employee.getName());
		Set<Role> roles = new HashSet<Role>();
		Role role = roleRepo.findByUserRole(UserRoles.ROLE_EMPLOYEE).orElseThrow();
		
		roles.add(role);
		user.setRoles(roles);
		User saveToDB = userRepo.save(user);
		return empRepo.save(employee);
	
	}


	@Override
	public Employee updateEmployeeDetails(Employee employee) {
		// TODO Auto-generated method stub
		return empRepo.save(employee);
	}


	@Override
	public String DeleteEmployeeDetails(int empId) {
		// TODO Auto-generated method stub
		if (empRepo.existsById(empId)) {
			empRepo.deleteById(empId);
			return "Employee Details deleted with" + empId;
		}
		return null;
	}

}
