package com.cdac.Service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.ServiceTypeRepository;
import com.cdac.entity.ServiceType;
@Service
@Transactional
public class ServiceTypeImpl implements IServiceType {

	@Autowired
	private ServiceTypeRepository serviceTypeRepo;
	
	
	@Override
	public List<ServiceType> getServiceTypeList() {
		// TODO Auto-generated method stub
		return serviceTypeRepo.findAll();
	}


	@Override
	public ServiceType addServiceType(ServiceType servType) {
		// TODO Auto-generated method stub
		return serviceTypeRepo.save(servType);
	}

}
