package com.cdac.Service;

import java.util.List;

import com.cdac.entity.ServiceType;



public interface IServiceType {
	
	List<ServiceType> getServiceTypeList();

	ServiceType addServiceType(ServiceType servType);

}
