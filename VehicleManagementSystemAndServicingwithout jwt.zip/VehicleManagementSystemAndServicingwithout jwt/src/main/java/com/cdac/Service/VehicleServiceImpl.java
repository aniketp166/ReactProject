package com.cdac.Service;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.cdac.CustomException.ResourceNotFoundException;
import com.cdac.dao.CustomerAdmRepository;
import com.cdac.dao.VehicleModelRepository;
import com.cdac.dao.VehicleRepository;
import com.cdac.entity.Customer;
import com.cdac.entity.Vehicle;
import com.cdac.entity.VehicleModel;
import com.univocity.parsers.common.record.Record;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;

@Service
@Transactional
public class VehicleServiceImpl implements IVehicleService {
	
	
	@Autowired
	private VehicleRepository vehicleRepo;
	
	@Autowired
	private CustomerAdmRepository customerRepo;
	
	@Autowired
	private VehicleModelRepository vehicleModelRepo;
	
	@Value("${file.upload.location}")
	private String location;
	
	@Override
	public List<Vehicle> listOfVehicles() {
		// TODO Auto-generated method stub
		return vehicleRepo.findAll();
	}

	@Override
	public String addVehiclesList(MultipartFile vehicleList) throws IOException {
		// TODO Auto-generated method stub
		List<Vehicle> listOfVehicle = new ArrayList<>();
		InputStream inputStream = vehicleList.getInputStream();
		CsvParserSettings settings = new CsvParserSettings();
		settings.setHeaderExtractionEnabled(true);
		CsvParser parser = new CsvParser(settings);
		List<Record> parserAllRecords = parser.parseAllRecords(inputStream);
		parserAllRecords.forEach(record ->{
			Vehicle vehicle = new Vehicle();
			vehicle.setChassisNo(record.getString("chasis_no"));
			vehicle.setEngineNo(record.getString("engine_no"));
			vehicle.setColor(record.getString("color"));
			vehicle.setVehicleType(record.getString("vehicle_type"));
			vehicle.setModelName(record.getString("model_name"));
			vehicle.setPrice(record.getByte("price"));
			listOfVehicle.add(vehicle);
		});
		vehicleRepo.saveAll(listOfVehicle);
		return "Data uploaded";
	}

	@Override
	public Vehicle updateVehicleDetails(Vehicle vehiclenew) {
		// TODO Auto-generated method stub
		return vehicleRepo.save(vehiclenew);
	}

	@Override
	public String deleteVehicleDetails(String chassisNo) {
		// TODO Auto-generated method stub
		if(vehicleRepo.existsById(chassisNo)) {
			vehicleRepo.deleteById(chassisNo);
			return "Vehicle Details deleted with "+chassisNo;
		}
		return null;
	}

	@Override
	public List<Vehicle> soldVehicles() {
		// TODO Auto-generated method stub
		return vehicleRepo.soldVehicles();
	}

	@Override
	public Vehicle getVehicleDetailsByChassisNo(String chassisNo) {
		// TODO Auto-generated method stub
		return vehicleRepo.findById(chassisNo).orElseThrow(
				() -> new ResourceNotFoundException("Vehicle with ChassisNo "+chassisNo + "not found....!!!!"));
			
	}

	@Override
	public List<Vehicle> listOfBookedVehicles() {
		// TODO Auto-generated method stub
		return vehicleRepo.getListOfBookedVehicle();
	}

	@Override
	public Vehicle purchaseVehicle(String vehId) {
		// TODO Auto-generated method stub
		Vehicle toPurchase = vehicleRepo.findById(vehId).orElseThrow();
		if(toPurchase != null) {
			toPurchase.setPurchasedStatus(true);
			toPurchase.setDateOfPurchase(LocalDate.now());
			return vehicleRepo.save(toPurchase);		
	}
		return null;
	}

	@Override
	public int addVehicleNumber(String vehicleNumber, String chNo) {
		// TODO Auto-generated method stub
		return vehicleRepo.addVehicleNumber(vehicleNumber,chNo);
	}

	@Override
	public String checkAvailabilityForBooking(String modelName, String color) {
		// TODO Auto-generated method stub
		List<Vehicle> vehicleList = vehicleRepo.bookingVehicle(modelName, color);
		return null;
	}

	@Override
	public Vehicle bookVehicle(String modelName, String color, Integer custId) {
		// TODO Auto-generated method stub
		Customer cust = customerRepo.findById(custId).orElseThrow();
		List<Vehicle> vehicleList =vehicleRepo.bookingVehicle(modelName, color);
		if(!vehicleList.isEmpty()) {
			Vehicle booked = vehicleList.get(0);
			booked.setBookedStatus(true);
			booked.setCustomer(cust);
			booked.setDateOfBooking(LocalDate.now());
			
			VehicleModel vehModel = vehicleModelRepo.findByModelName(modelName);
			vehModel.setQuantity(vehModel.getQuantity()-1);
			return vehicleRepo.save(booked);
		}
		return null;
	}

	
	
	
}
