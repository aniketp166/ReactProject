package com.cdac.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class ErrorResponse {
	private String message;
	private LocalDateTime timestamp;
}
