package com.cdac.dto;

import lombok.Data;

@Data
public class VehicleDto {
		
	private String ChassisNo;
	private String engineNo;
	private String ModelName;
	private String vehicleNo;
	private String vehicleType;
	private double price;
	private String color;
}
