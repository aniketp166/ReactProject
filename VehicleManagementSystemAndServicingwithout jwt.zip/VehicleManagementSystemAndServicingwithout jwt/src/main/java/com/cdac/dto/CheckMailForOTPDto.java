package com.cdac.dto;

import lombok.Data;

@Data
public class CheckMailForOTPDto {
	
	public String email;
}
