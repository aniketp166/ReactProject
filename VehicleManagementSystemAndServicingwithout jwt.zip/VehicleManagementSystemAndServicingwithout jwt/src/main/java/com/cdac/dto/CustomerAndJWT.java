package com.cdac.dto;

import com.cdac.entity.Customer;

import lombok.Data;

@Data
public class CustomerAndJWT {
	private Customer customer;
	private String jwt;
	private String userRole;
}
