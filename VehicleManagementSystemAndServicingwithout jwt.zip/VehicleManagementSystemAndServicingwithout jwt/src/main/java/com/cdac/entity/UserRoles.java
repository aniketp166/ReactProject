package com.cdac.entity;

public enum UserRoles {
	ROLE_USER, ROLE_ADMIN,ROLE_EMPLOYEE
}
