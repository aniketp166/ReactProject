package com.cdac.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "customer_tb")
public class Customer extends BaseEntity {
	/*
	 * public Customer(int custId) { super(custId);//need to discuss weather to keep
	 * arguments or not // TODO Auto-generated constructor stub }
	 */
	@Column(name = "customer_name", nullable = false)
	private String name;

	@Column(nullable = false)
	@Embedded
	private Address address;

	@Column(name = "contact_no", nullable = false)
	private String contactNumber;

	@Column(name = "email_id", unique = true)
	private String emailId;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "registration_date")
	private LocalDate dateOfRegistration;
	
	private boolean active;
}
