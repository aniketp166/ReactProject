package com.cdac.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonProperty;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="admin_table")
public class Admin extends BaseEntity {


	@NotBlank(message="Please provide the firstname")
	@Column(length =30, name="first_name")
	@JsonProperty("name")
	private String firstname;
	
	@Length(min =3,max=29,message="Invalid length of lastname")
	@Column(length=30,name="last_name")
	private String lastname;
	
	@Column(length=30,unique=true)
	@NotBlank(message="Please provide the email")
	@Email
	private String email;
	
	@Column(length=30)
	@Pattern(regexp ="((?=.*\\d) (?=.*[a-z]) (?=.*[#@$*]).{5,20})" ,message="Invalid password")
	private String password;

	public Admin(@NotBlank(message = "Please provide the email") @Email String email,
			@Pattern(regexp = "((?=.*\\d) (?=.*[a-z]) (?=.*[#@$*]).{5,20})", message = "Invalid password") String password) {
		super();
		/*
		 * this.firstname = firstname; this.lastname = lastname;
		 */
		this.email = email;
		this.password = password;
	}

	
	
	
	
}
