package com.cdac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
//@EnableConfigurationProperties
//@EntityScan(basePackages = {"com.cdac.entity"})
////@Configuration
////@EnableAutoConfiguration
//@ComponentScan({"com.cdac.entity", "Controller", "Service"})
public class VehicleManagementSystemAndServicing1Application {

	public static void main(String[] args) {
		SpringApplication.run(VehicleManagementSystemAndServicing1Application.class, args);
//		Admin ad =new Admin();
//	ad.setEmail("vp18");
//		System.out.println(ad.getEmail());
		System.out.println("running application");
	}

}
