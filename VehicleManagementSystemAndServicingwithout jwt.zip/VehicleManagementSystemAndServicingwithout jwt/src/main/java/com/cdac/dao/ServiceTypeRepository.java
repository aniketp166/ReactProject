package com.cdac.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.entity.ServiceType;

public interface ServiceTypeRepository extends JpaRepository<ServiceType, Integer> {

}
