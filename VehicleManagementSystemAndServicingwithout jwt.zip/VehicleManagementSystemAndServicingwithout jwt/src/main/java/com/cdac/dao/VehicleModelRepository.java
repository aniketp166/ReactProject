package com.cdac.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.entity.VehicleModel;

public interface VehicleModelRepository extends JpaRepository<VehicleModel, Integer> {
		VehicleModel findByModelName(String modelName);
}
