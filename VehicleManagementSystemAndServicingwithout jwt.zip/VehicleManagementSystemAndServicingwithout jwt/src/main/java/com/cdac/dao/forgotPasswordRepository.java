package com.cdac.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.entity.ForgotPassword;

public interface forgotPasswordRepository extends JpaRepository<ForgotPassword, Integer> {
		
	ForgotPassword findByEmail(String email);
}
