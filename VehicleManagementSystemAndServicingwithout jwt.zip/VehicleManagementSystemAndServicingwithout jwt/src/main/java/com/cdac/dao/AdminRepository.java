package com.cdac.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer> {
		
	Admin findByEmailAndPassword(String email, String password);
}
