package com.cdac.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cdac.entity.Customer;
import com.cdac.entity.Vehicle;
@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, String> {
	
	@Query(value="select v from Vehicle v where v.bookedStatus=false and v.purchasedStatus=false" )
	List<Vehicle> getListOfAvailablevehicle();

	
	@Query(value="select v from Vehicle v where v.purchasedStatus=true")
	List<Vehicle> soldVehicles();

	@Query(value="select v from Vehicle v where v.bookedStatus=true and v.purchasedStatus=false ")
	List<Vehicle> getListOfBookedVehicle();
	
	Vehicle findByCustomer(Customer customer);
	
	Vehicle findByChassisNo(String chassisNo);

	@Modifying
	@Query(value="update Vehicle v set v.vehicleNo = :vehicleNumber where v.chassisNo =:chNo")
	int addVehicleNumber(@Param("vehicleNumber")String vehicleNumber,@Param("chNo") String chNo);

	@Query(value="select distinct v from Vehicle v where v.modelName = :modelName and v.color = :color and v.bookedStatus = false and v.purchasedStatus = false")
	List<Vehicle> bookingVehicle(String modelName, String color);
}
