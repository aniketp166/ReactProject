package com.cdac.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.entity.Customer;

public interface CustomerAdmRepository extends JpaRepository<Customer, Integer> {

	Customer findByEmailId(String email);

}
